# (c) HYBRID

import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.environ.get('BOT_TOKEN', '7040259647:AAGsJONPM6kNAoYFSv9qLaniKdpvQNlRJQE')
API_ID = int(os.environ.get('API_ID', '3881325'))
API_HASH = os.environ.get('API_HASH', '1ebf12e67222683abe1c01f0209b79df') 
OWNER = []
OWNER_ID = int(os.environ.get('OWNER', '5186421949'))
OWNER.append(OWNER_ID)
OWNER.append(1412909688)
OWNER.append(6467186545)
MONGO_URL = os.environ.get('MONGO_URL', 'mongodb+srv://Sphinx:sphinx@cluster0.ptfc0rx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
START_IMG = os.environ.get('START_IMG', False)
LOG_ID = int(os.environ.get('LOG_ID', '-1001778730930'))
VERSION = "0.0.1"
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgres://jihgpchb:y63fbn9vzUeAxqGLrKuTphnv-8MjTgrU@rain.db.elephantsql.com/jihgpchb')
UN_CLAIM = os.environ.get('UN_CLAIM', '@its_sphinx')
SESSION_STRING = [
    "BQGPKiAAFfycpRhHUnztzMwQJRIlPzxT_Ej6issgvljuC7zuZPiDVfIP2adiLPXctdz-oDy0pH-4lyIehcIcICSRhWLXepfu5gadvdZEM7S4kjibLUyaj__jt-EY-j8m1LKo0i52R9R9ygAkN5MVvZ28a-jvJBi_qnCqjqZePSEjtt2HkdIisFvSYP4Dg6WHK2mk8GhwEpsIBI1zL2mm53PJOvFOWSRiH_65-5tdzStkVTpnWOLmk9WQR_TvYLmAX7Uk3Ab-IliFiVdWQ3XDFtEYWi1nsJ6KBLck7ZlQRnoepxbNnZb6xDx-2_luUgC8IToemZQLkeFsQt6Op3dIpYCok7nJ6gAAAAE1IoS9AA",
    "BQGPKiAAOEQT-qJuyq4IOyBjph5hFThCeBxI8n1977by1NymH9InJa1wxMpw1gSSo7is7wqQcn28oXi37VwVMmF9YnzH8OF4OBJoW1-zKSw9GOwmMUzILaxlKyA4fYWzbjEKWJgs-OxsHFG2WSptH-WtRGuKlILe-a7aXsdS-jTZLuVmovwwE6cEGZy4euCcyoWdegWk-Eb8-ruVDkyINGNrzrhKvHJ1-tRjLSnWsarsR5EAmars2qOm7IibWeEHlMF2sNn_PE8a7OEXWq7RuMvrCRhU7X22juA__t7uvd5s77ZYq_nXM8zt09caqIhW5ATnkHA4UyFlM7TKTB5BvtFzYXAEZwAAAAGBeW9xAA",
    "AQGPKiAAZVw14u6kUZP-KVpgFcR51Sja38OrM2Ntzc1eCi12AlOJn1pFC7wN80PKBYE-AAn3D3K8Rg83ZPHwHAWwMSp0gPJ_WPMNlGpCBIfs-ywfEqgKcNH7ibiPijeReI-dL-MoFMXaBdYoYFTIS4_diLOvGKYfV2qp_2X5trQLVWRqDUF2YOooCI7afsSkIkowEz5_8krCWnldFVzZ26JZ0OcxDIzbVBlunC3wrbydqWgjlEapEZt64WJnM-S7PhwQNWOsaJBXU-r9UeJjywRJ5uGAXk6FvSmUZVJSlE9j7GSfx7kc6lyc7zVYRFZwN__PTUHmLcbqNZM-R0WCzBF033hvJQAAAAErpXPYAA"
]

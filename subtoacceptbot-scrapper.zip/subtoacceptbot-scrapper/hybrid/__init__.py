# (c) HYBRID

from os import path
import asyncio
import logging
import asyncpg

from pyrogram import Client
from pyromod import listen
from motor.motor_asyncio import AsyncIOMotorClient as MongoClient

from hybrid.temp import temp

logging.basicConfig(level=logging.DEBUG,
                    format='%(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logging.getLogger("pyrogram").setLevel(logging.WARNING)
logging.getLogger("pyrogram.parser").setLevel(logging.CRITICAL)
logging.getLogger("pyrogram.session").setLevel(logging.CRITICAL)
logging.getLogger("urllib3.connectionpool").setLevel(logging.CRITICAL)

is_config = path.exists("config.py")

if is_config:
    from config import *
else:
    from sample_config import *

mongo_client = MongoClient(MONGO_URL)
db = mongo_client.subsdb
usersdb = db.users



async def create_table_if_not_exists():
    conn = await asyncpg.connect(DATABASE_URL)
    try:
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS strings (
                id serial PRIMARY KEY,
                value text UNIQUE
            )
        ''')
    finally:
        await conn.close()

app = Client(
    name="subtoa",
    api_id=API_ID,
    api_hash=API_HASH,
    bot_token=BOT_TOKEN,
    plugins={"root": "hybrid/plugins"},
    workers=100,
)

CLIENTS = []
RUNNING = temp.RUNNING

for session in SESSION_STRING:
    try:
        client = Client(
            name="hybridub",
            api_id=API_ID,
            api_hash=API_HASH,
            session_string=session,
        )
        CLIENTS.append(client)
    except Exception as e:
        logging.info(f"Error on Strings: {e}")

async def load_func():
    if RUNNING:
        logging.info("Running Status found on start, cleaning...")
        RUNNING.clear()
        logging.info("Cleared Running List.")

    await create_table_if_not_exists()

    logging.info("Starting user sessions")
    for client in CLIENTS:
        try:
            await client.start()
            user = await client.get_me()
            logging.info(f"Started session client for {user.first_name}")
        except Exception as e:
            logging.info(f"Error while starting a client: {e}")
    logging.info(f"Started user sessions")

loop = asyncio.get_event_loop()
loop.run_until_complete(load_func())

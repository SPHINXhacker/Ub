# (c) HYBRID

import logging

from pyrogram import Client, filters
from pyrogram.enums import ChatMembersFilter
from pyrogram.types import CallbackQuery, ChatMemberUpdated, ChatPermissions, ChatPrivileges, Message, InlineKeyboardButton, InlineKeyboardMarkup

from hybrid import app, VERSION, CLIENTS
from hybrid.plugins.error import capture_err
from hybrid.database.db import remove_fsub, remove_flink, remove_mainc, has_chan, fetch_fsub, fetch_flink
from hybrid.temp import temp
from hybrid.plugins.func import remove_UN

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

@app.on_callback_query(filters.regex(r"del#(\d+)"))
@capture_err
async def channel_del_handler(_, query):
    data = query.data
    ch_id = int(data.split("#")[1])
    word = data.split("#")[2]
    await query.message.edit(f"🔃 **Processing {word}**.....")
    try:
        if word.startswith("-100"):
            ch_id = int(word)
        await query.message.edit(f"🔃 **Processing {word}**....")
        if ch_id == 12345:
            for uapp in CLIENTS:
                try:
                    msg = await uapp.send_message(word, "Deletion in progress**...")
                    ch_id = msg.chat.id
                    break
                except:
                    continue

        keyboard = [
            [
                InlineKeyboardButton("❌ Yes Delete", callback_data=f"delch_confirm#{ch_id}#{word}"),
                InlineKeyboardButton("🔻 Close", callback_data="close"),
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit(f"**Are you sure to delete @{word}** ?", reply_markup=reply_markup)
    except Exception as e:
        text = query.message.text + f"\n\n```Error:\n{e}```"
        await query.message.edit(text)

@app.on_callback_query(filters.regex(r"delch_confirm#(.*?)"))
@capture_err
async def del_ch_handler(_, query):
    data = query.data
    ch_id = int(data.split("#")[1])
    word = data.split("#")[2]
    txt = f"**Process started for @{word}**...."
    await query.message.edit(txt)
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            txt = f"🔃 **Processing @{word} with** {user.first_name}"
            await query.message.edit(txt)
            delete = await uapp.delete_channel(ch_id)
            if delete:
                txt = f"❌ **Deleted @{word} by** {user.first_name}"
                await query.message.edit(txt)
                try:
                    listmsg = await app.get_messages(-1001153216655, 51)
                    texts = listmsg.text
                    new_list = await remove_UN(word, texts)
                    await listmsg.edit(new_list)
                except Exception:
                    pass
                break
            else:
                continue
        except Exception as e:
            continue

@app.on_callback_query(filters.regex("close"))
@capture_err
async def cb_close(_, query):
    await query.message.edit("⏳")
    await query.message.delete()


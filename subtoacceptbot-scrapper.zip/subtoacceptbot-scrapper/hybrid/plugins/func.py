# (c) HYBRID
import asyncio
import requests
import re
import os
import random

from urllib.parse import urlparse, parse_qs
from pyrogram import Client, filters
from pyrogram.enums import ChatMemberStatus
from pyrogram.types import Message, InlineKeyboardButton, InlineKeyboardMarkup
from pyrogram.errors import ChannelInvalid
from pyrogram.raw.functions.account import CheckUsername
from pyrogram.errors import FloodWait

from hybrid import app, CLIENTS, logger, UN_CLAIM
from hybrid.temp import temp
from PyDictionary import PyDictionary

async def find_admin(id, new):
    for uapp in CLIENTS:
        try:
            user = await uapp.promote_chat_member(chat_id=id, user_id=new)
            if user:
                return uapp
            continue
        except Exception as e:
            continue
    return False

def is_valid_word(word):
    return bool(re.match("^[a-zA-Z]+$", word))

def process_word_file(file_path, n):
    try:
        with open(file_path, 'r') as file:
            words = [word.strip() for word in file.readlines() if len(word.strip()) == n and re.match("^[a-zA-Z]+$", word)]

        return words

    except Exception as e:
        print(f"Error processing file '{file_path}': {e}")
        return []

async def process_word_file_range(file_path, n, m):
    try:
        with open(file_path, 'r') as file:
            lines = file.readlines()

            words = []
            for line in lines:
                if ' ' in line:
                    line_words = [re.sub(r'[^a-zA-Z]', '', word.strip()) for word in line.split()]
                    words.extend([word for word in line_words if n <= len(word) <= m])
                else:
                    word = re.sub(r'[^a-zA-Z]', '', line.strip())
                    if n <= len(word) <= m:
                        words.append(word)

            return words

    except Exception as e:
        print(f"Error processing file '{file_path}': {e}")
        return False

async def get_range(n, m, msg):
    valid_words = []
    try:
        folder_path = 'hybrid/words'
        files = [file for file in os.listdir(folder_path) if file.endswith('.txt')]
        await msg.edit(f"Found **{len(files)}** txt files...")
        tasks = []
        for file in files:
            await msg.edit(f"🔃 Processing: `{file}`")
            file_path = os.path.join(folder_path, file)
            task = process_word_file_range(file_path, n, m)
            tasks.append(task)

        valid_words_lists = await asyncio.gather(*tasks)
        await msg.edit(f"🔃 Processing from **{len(tasks)}** words")
        for words in valid_words_lists:
            valid_words.extend(words)
            
        await msg.edit(f"🔃 Matched **{len(valid_words)}** words")
        random.shuffle(valid_words)
        return valid_words
    except Exception as e:
        await msg.edit(f"```Error while making wordlist:\n{e}```")
        print(f"Error processing folder '{folder_path}': {e}")
        return False

def get_words(n):
    valid_words = []
    try:
        folder_path = 'hybrid/words'
        files = [file for file in os.listdir(folder_path) if file.endswith('.txt')]

        for file in files:
            file_path = os.path.join(folder_path, file)
            words = process_word_file(file_path, n)
            valid_words.extend(words)
        random.shuffle(valid_words)
        return valid_words

    except Exception as e:
        print(f"Error processing folder '{folder_path}': {e}")
        return False
    
def get_valid_words(length_range=[5, 6], max_results=10000):
    url = "https://api.datamuse.com/words"

    min_length, max_length = length_range

    pattern = f"{'?' * min_length}{'' if min_length == max_length else f'{{{max_length - min_length + 1}}}' if max_length > min_length else ''}"

    params = {
        "sp": pattern,
        "max": max_results,
    }

    response = requests.get(url, params=params)

    if response.status_code == 200:
        words_info = response.json()
        valid_meaningful_words = [info["word"] for info in words_info]

        return valid_meaningful_words
    else:
        english_words = set(words.words())
        words_list = [word.lower() for word in english_words if len(word) == n]
        return words_list

async def check_un(word, msg):
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            ucheck = await uapp.invoke(CheckUsername(username=word))
            return ucheck
        except FloodWait as e:
            text = msg.text + f"\n\n```Floodwait {user.first_name} @{word}:\n{e}```"
            await msg.edit(text)
            print(f"Error check_un {user.first_name}: {e}")
            await asyncio.sleep(2)
            continue
        except Exception as e:
            text = msg.text + f"\n\n```Error {user.first_name} @{word}:\n{e}```"
            await msg.edit(text)
            print(f"Error check_un {user.first_name}: {e}")
            await asyncio.sleep(2)
            return False
    return "Flood"

async def remove_UN(word, text):
    lines = text.split('\n')
    updated_text = '\n'.join(line for line in lines if word not in line)
    return updated_text

async def claim_un(word, msg):
    for uapp in CLIENTS:
        try:
            user = await uapp.get_me()
            chat = await uapp.create_channel(f"@{word}", "@Hybrid_Vamp")
            ch_id = chat.id
            success = await uapp.set_chat_username(ch_id, word)
            if success:
                await uapp.send_message(ch_id, f"Username Claimed By {UN_CLAIM}")
                return f"{user.first_name}", ch_id
            else:
                try:
                    await uapp.delete_channel(chat_id=ch_id)
                except:
                    pass
        except Exception as e:
            print(f"Error claim_un {user.first_name} @{word}: {e}")
            text = msg.text + f"\n\n```Error: {user.first_name} @{word}:\n{e}```"
            await msg.edit(text)
            try:
                await uapp.delete_channel(chat_id=ch_id)
            except:
                continue
            continue
    return False, False

def is_valid(word):
    dictionary = PyDictionary()
    try:
        meanings = dictionary.meaning(word)
        return bool(meanings)
    except Exception as e:
        print(f"Error: {e}")
        return False

def parse_url(url: str):
    parsed = urlparse(url)
    path = parsed.path[1:]

    query_params = parse_qs(parsed.query)
    start_param = query_params.get('start')

    if start_param:
        start_value = start_param[0]
    else:
        # If 'start' parameter is not provided, generate a random letter
        start_value = f"\u2063"

    return path, start_value
